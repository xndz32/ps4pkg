#!/usr/bin/env bash
# Baixa o OpenOrbis Toolchain, compila o jogo e publica o .pkg numa Release do GitHub.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
export DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1

sudo apt-get update -qq
sudo apt-get install -y -qq clang lld

AUTH=(); [ -n "${GH_TOKEN:-}" ] && AUTH=(-H "Authorization: Bearer $GH_TOKEN")
mkdir -p "$HOME/oo" && cd "$HOME/oo"
curl -sL ${AUTH[@]+"${AUTH[@]}"} https://api.github.com/repos/OpenOrbis/OpenOrbis-PS4-Toolchain/releases/latest -o rel.json
URL="$(python3 "$ROOT/ci/pick_asset.py" < rel.json)"
if [ -z "$URL" ]; then
  TAG="$(python3 -c "import json;print(json.load(open('rel.json')).get('tag_name',''))")"
  [ -n "$TAG" ] || { echo "ERRO: nao consegui consultar a API do GitHub"; head -c 400 rel.json; exit 1; }
  URL="https://github.com/OpenOrbis/OpenOrbis-PS4-Toolchain/releases/download/$TAG/$TAG.tar.gz"
fi
echo "Baixando o toolchain: $URL"
curl -sL "$URL" -o toolchain.bin
case "$URL" in *.zip) unzip -q toolchain.bin ;; *) tar xzf toolchain.bin ;; esac

LINKX="$(find "$HOME/oo" -name link.x | head -n 1)"
[ -n "$LINKX" ] || { echo "ERRO: link.x nao encontrado no toolchain"; ls "$HOME/oo" | head -30; exit 1; }
export OO_PS4_TOOLCHAIN="$(dirname "$LINKX")"
chmod -R +x "$OO_PS4_TOOLCHAIN/bin" 2>/dev/null || true
echo "OO_PS4_TOOLCHAIN=$OO_PS4_TOOLCHAIN"
ls "$OO_PS4_TOOLCHAIN"
find "$OO_PS4_TOOLCHAIN" \( -name 'libSDL2*' -o -name right.sprx -o -name libc.prx -o -name libSceFios2.prx -o -name SDL.h \) | head -20

cd "$ROOT"
make
PKG="$(ls -1 ./*.pkg | head -n 1)"
echo "PKG gerado: $PKG ($(du -h "$PKG" | cut -f1))"

if [ -n "${GH_TOKEN:-}" ]; then
  gh release create "v${GITHUB_RUN_NUMBER:-$(date +%s)}" "$PKG" \
    --title "Zombies Coming (build ${GITHUB_RUN_NUMBER:-0})" \
    --notes "Arquivo .pkg para instalar no PS4 (homebrew)." \
    || echo "Aviso: nao consegui criar a Release; baixe o .pkg em Artifacts."
fi
