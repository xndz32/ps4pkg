import json, sys
r = json.load(sys.stdin)
a = [x["browser_download_url"] for x in r.get("assets", [])]
lo = lambda u: u.lower()
c = [u for u in a if "linux" in lo(u) and lo(u).endswith((".tar.gz", ".zip"))]
c += [u for u in a if lo(u).endswith(".tar.gz")]
c += [u for u in a if lo(u).endswith(".zip")]
print(c[0] if c else "")
