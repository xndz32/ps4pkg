/* Zombies Coming - nucleo do jogo. Desenha so com retangulos (fill). */
#include "game.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "logo.h"

#define WS 2400.f
#define MAXZ 256
#define MAXB 160
#define MAXM 16
#define PI 3.14159265f

typedef struct { float x, y, a, cd, hit; int hp, dead; uint32_t col; } Pl;
typedef struct { float x, y, a, cd, ph, s, r; int hp, dm, k; uint32_t col; } Zb;
typedef struct { float x, y, vx, vy, t; } Bu;
typedef struct { float x, y, t; } Md;
enum { S_MENU, S_PLAY, S_PAUSE, S_OVER, S_HELP, S_TEST };

static FillFn fillfn;
static int W = 1280, H = 720, canQuit, quitFlag, state = S_MENU, sel, mode = 1, ncon;
static Pl P[2]; static Zb Z[MAXZ]; static Bu B[MAXB]; static Md M[MAXM];
static int nz, nb, nm, wave, left, score, hi;
static float wt, sT, banner, T, lock, OX, OY;
static int cx0, cy0, cx1, cy1;
static uint32_t rng = 12345;
static char dbg[600];

static float rnd(void) { rng = rng * 1664525u + 1013904223u; return (rng >> 8) / 16777216.f; }
static float cl(float v) { return v < 20 ? 20 : v > WS - 20 ? WS - 20 : v; }

static void clip(int x, int y, int w, int h) { cx0 = x; cy0 = y; cx1 = x + w; cy1 = y + h; }
static void rect(float x, float y, float w, float h, uint32_t c) {
    int x0 = (int)floorf(x), y0 = (int)floorf(y), x1 = (int)ceilf(x + w), y1 = (int)ceilf(y + h);
    if (x0 < cx0) x0 = cx0;
    if (y0 < cy0) y0 = cy0;
    if (x1 > cx1) x1 = cx1;
    if (y1 > cy1) y1 = cy1;
    if (x1 > x0 && y1 > y0) fillfn(x0, y0, x1 - x0, y1 - y0, c);
}
static void wrect(float x, float y, float w, float h, uint32_t c) { rect(x + OX, y + OY, w, h, c); }

/* fonte 3x5 (so maiusculas) */
static const struct { char c; const char *g; } FONT[] = {
{'0',"111101101101111"},{'1',"010110010010111"},{'2',"111001111100111"},{'3',"111001111001111"},{'4',"101101111001001"},
{'5',"111100111001111"},{'6',"111100111101111"},{'7',"111001001001001"},{'8',"111101111101111"},{'9',"111101111001111"},
{'A',"111101111101101"},{'B',"110101110101110"},{'C',"111100100100111"},{'D',"110101101101110"},{'E',"111100110100111"},
{'F',"111100110100100"},{'G',"111100101101111"},{'H',"101101111101101"},{'I',"111010010010111"},{'J',"001001001101111"},
{'K',"101101110101101"},{'L',"100100100100111"},{'M',"101111111101101"},{'N',"110101101101101"},{'O',"111101101101111"},
{'P',"111101111100100"},{'Q',"111101101111001"},{'R',"110101110101101"},{'S',"111100111001111"},{'T',"111010010010010"},
{'U',"101101101101111"},{'V',"101101101101010"},{'W',"101101111111101"},{'X',"101101010101101"},{'Y',"101101010010010"},
{'Z',"111001010100111"},{'.',"000000000000010"},{':',"000010000010000"},{'-',"000000111000000"},{'/',"001001010100100"},
{'(',"010100100100010"},{')',"010001001001010"},{'+',"000010111010000"},{'!',"010010010000010"},{'?',"111001010000010"},
{'<',"001010100010001"},{'>',"100010001010100"},{',',"000000000010100"}};

static void text(float x, float y, int sc, const char *s, uint32_t c, int al) {
    float w = (float)strlen(s) * 4 * sc - sc;
    if (al == 1) x -= w / 2; else if (al == 2) x -= w;
    for (; *s; s++, x += 4 * sc) {
        char ch = *s; if (ch >= 'a' && ch <= 'z') ch -= 32;
        if (ch == ' ') continue;
        for (unsigned i = 0; i < sizeof FONT / sizeof *FONT; i++) if (FONT[i].c == ch) {
            const char *g = FONT[i].g;
            for (int r = 0; r < 5; r++) for (int q = 0; q < 3;) {
                if (g[r * 3 + q] == '1') { int e = q; while (e < 3 && g[r * 3 + e] == '1') e++;
                    rect(x + q * sc, y + r * sc, (float)(e - q) * sc, (float)sc, c); q = e; }
                else q++;
            }
            break;
        }
    }
}

static void start(int n) {
    mode = n; state = S_PLAY; memset(P, 0, sizeof P);
    for (int i = 0; i < n; i++) { P[i].x = WS / 2 + i * 50; P[i].y = WS / 2; P[i].hp = 100; P[i].col = i ? 0x3399FF : 0xFF4433; }
    nz = nb = nm = 0; wave = left = score = 0; wt = 1.5f; sT = banner = 0;
}
static void gameover(void) { state = S_OVER; sel = 0; lock = 1.2f; if (score > hi) hi = score; }

static void spawn(void) {
    int al[2], na = 0;
    for (int i = 0; i < mode; i++) if (!P[i].dead) al[na++] = i;
    if (!na || nz >= MAXZ) return;
    Pl *p = &P[al[(int)(rnd() * na) % na]];
    float a = rnd() * 2 * PI, d = (W > H ? W : H) * .6f, r = rnd();
    int k = (wave > 2 && r < .12f) ? 2 : (wave > 1 && r < .4f) ? 1 : 0;
    static const struct { int hp; float s, r; int dm; uint32_t c; } TY[3] = {
        {50, 70, 14, 10, 0x44AA44}, {30, 125, 11, 8, 0x99CC33}, {220, 48, 22, 25, 0x338866}};
    Zb *z = &Z[nz++];
    z->x = cl(p->x + cosf(a) * d); z->y = cl(p->y + sinf(a) * d);
    z->hp = TY[k].hp; z->s = TY[k].s * (1 + wave * .03f); z->r = TY[k].r; z->dm = TY[k].dm;
    z->col = TY[k].c; z->k = k; z->a = 0; z->cd = 0; z->ph = rnd() * 9;
    left--;
}

static void upd_play(float dt, const Input *in) {
    T += dt; banner -= dt;
    int vw = mode == 2 ? W / 2 : W;
    for (int i = 0; i < mode; i++) {
        Pl *p = &P[i]; const Input *n = &in[i];
        if (p->dead) continue;
        float l = sqrtf(n->mx * n->mx + n->my * n->my), k = l > 1 ? 1 / l : 1;
        p->x = cl(p->x + n->mx * k * 210 * dt); p->y = cl(p->y + n->my * k * 210 * dt);
        if (n->ax != 0 || n->ay != 0) p->a = atan2f(n->ay, n->ax);
        else if (i == 0 && n->hasM) p->a = atan2f(n->mpy - H * .5f, n->mpx - vw * .5f);
        else if (n->f && (n->mx != 0 || n->my != 0)) p->a = atan2f(n->my, n->mx);
        p->cd -= dt; p->hit -= dt;
        if (n->f && p->cd <= 0 && nb < MAXB) {
            p->cd = .13f; float a = p->a + (rnd() - .5f) * .1f; Bu *b = &B[nb++];
            b->x = p->x + cosf(p->a) * 20; b->y = p->y + sinf(p->a) * 20;
            b->vx = cosf(a) * 780; b->vy = sinf(a) * 780; b->t = .7f;
        }
    }
    if (left <= 0 && nz == 0) {
        wt -= dt;
        if (wt <= 0) { wave++; left = 4 + wave * 4; wt = 3; banner = 2;
            for (int i = 0; i < mode; i++) if (P[i].dead) { P[i].dead = 0; P[i].hp = 60; } }
    } else if (left > 0) {
        sT -= dt; if (sT <= 0) { spawn(); sT = fmaxf(.12f, .9f - wave * .06f); }
    }
    for (int j = 0; j < nz; j++) {
        Zb *z = &Z[j]; Pl *b = NULL; float bd = 1e9f;
        for (int i = 0; i < mode; i++) {
            if (P[i].dead) continue;
            float d = hypotf(P[i].x - z->x, P[i].y - z->y); if (d < bd) { bd = d; b = &P[i]; }
        }
        if (!b) continue;
        z->a = atan2f(b->y - z->y, b->x - z->x) + sinf(T * 2 + z->ph) * .5f * fminf(1, bd / 150);
        z->x += cosf(z->a) * z->s * dt; z->y += sinf(z->a) * z->s * dt; z->cd -= dt;
        if (bd < z->r + 14 && z->cd <= 0) { z->cd = .8f; b->hp -= z->dm; b->hit = .2f; if (b->hp <= 0) { b->hp = 0; b->dead = 1; } }
    }
    for (int i = 0; i < nb; i++) {
        Bu *b = &B[i]; b->x += b->vx * dt; b->y += b->vy * dt; b->t -= dt;
        for (int j = 0; j < nz; j++) {
            Zb *z = &Z[j];
            if (z->hp > 0 && hypotf(z->x - b->x, z->y - b->y) < z->r + 4) {
                z->hp -= 25; z->x += b->vx * .02f; z->y += b->vy * .02f; b->t = 0;
                if (z->hp <= 0) { score += 10 * (1 + z->k);
                    if (rnd() < .08f && nm < MAXM) { M[nm].x = z->x; M[nm].y = z->y; M[nm].t = 12; nm++; } }
                break;
            }
        }
    }
    int w = 0;
    for (int i = 0; i < nb; i++) if (B[i].t > 0) B[w++] = B[i];
    nb = w; w = 0;
    for (int j = 0; j < nz; j++) if (Z[j].hp > 0) Z[w++] = Z[j];
    nz = w; w = 0;
    for (int i = 0; i < nm; i++) {
        M[i].t -= dt;
        for (int p = 0; p < mode; p++) if (!P[p].dead && hypotf(P[p].x - M[i].x, P[p].y - M[i].y) < 24) {
            P[p].hp = P[p].hp + 35 > 100 ? 100 : P[p].hp + 35; M[i].t = 0; }
        if (M[i].t > 0) M[w++] = M[i];
    }
    nm = w;
    int alive = 0; for (int i = 0; i < mode; i++) if (!P[i].dead) alive++;
    if (!alive) gameover();
}

static int pick(Nav nv, int n) {
    if (nv.up) sel = (sel + n - 1) % n;
    if (nv.down) sel = (sel + 1) % n;
    return nv.ok ? sel : -1;
}

void game_init(int w, int h, FillFn fill, int can_quit) { W = w; H = h; fillfn = fill; canQuit = can_quit; state = S_MENU; sel = 0; }
void game_set_debug(const char *s) { strncpy(dbg, s, sizeof dbg - 1); dbg[sizeof dbg - 1] = 0; }
int game_quit(void) { return quitFlag; }
int game_players(void) { return mode; }

void game_update(float dt, const Input in[2], Nav nv, int nc) {
    ncon = nc; if (lock > 0) lock -= dt;
    int c;
    switch (state) {
    case S_PLAY: if (nv.pause) { state = S_PAUSE; sel = 0; } else upd_play(dt, in); break;
    case S_PAUSE:
        if (nv.pause) { state = S_PLAY; break; }
        c = pick(nv, 2); if (c == 0) state = S_PLAY; else if (c == 1) { state = S_MENU; sel = 0; }
        break;
    case S_OVER:
        if (lock > 0) nv.ok = 0;
        c = pick(nv, 2); if (c == 0) start(mode); else if (c == 1) { state = S_MENU; sel = 0; }
        break;
    case S_HELP: case S_TEST:
        if (pick(nv, 1) == 0 || nv.pause) { sel = state == S_HELP ? 2 : 3; state = S_MENU; }
        break;
    default:
        c = pick(nv, canQuit ? 5 : 4);
        if (c == 0) start(1); else if (c == 1) start(2);
        else if (c == 2) { state = S_HELP; sel = 0; } else if (c == 3) { state = S_TEST; sel = 0; }
        else if (c == 4 || (nv.pause && canQuit)) quitFlag = 1;
    }
}

static void draw_view(const Pl *p, int vx, int vw, int idx) {
    clip(vx, 0, vw, H); OX = vx + vw / 2.f - p->x; OY = H / 2.f - p->y;
    wrect(0, 0, WS, WS, 0x140707);
    float gx0 = fmaxf(0, p->x - vw / 2.f), gx1 = fminf(WS, p->x + vw / 2.f);
    float gy0 = fmaxf(0, p->y - H / 2.f), gy1 = fminf(WS, p->y + H / 2.f);
    for (float a = floorf(gx0 / 80) * 80; a <= gx1; a += 80) if (a >= 0) wrect(a, gy0, 1, gy1 - gy0, 0x2B0D0D);
    for (float a = floorf(gy0 / 80) * 80; a <= gy1; a += 80) if (a >= 0) wrect(gx0, a, gx1 - gx0, 1, 0x2B0D0D);
    wrect(-8, -8, WS + 16, 8, 0xC01000); wrect(-8, WS, WS + 16, 8, 0xC01000);
    wrect(-8, 0, 8, WS, 0xC01000); wrect(WS, 0, 8, WS, 0xC01000);
    for (int i = 0; i < nm; i++) { wrect(M[i].x - 9, M[i].y - 9, 18, 18, 0xFFFFFF);
        wrect(M[i].x - 2, M[i].y - 7, 4, 14, 0xEE2222); wrect(M[i].x - 7, M[i].y - 2, 14, 4, 0xEE2222); }
    for (int j = 0; j < nz; j++) {
        const Zb *z = &Z[j]; float ex = cosf(z->a), ey = sinf(z->a);
        wrect(z->x - z->r, z->y - z->r, 2 * z->r, 2 * z->r, z->col);
        for (int s = -1; s <= 1; s += 2)
            wrect(z->x + ex * z->r * .5f - ey * z->r * .4f * s - 2, z->y + ey * z->r * .5f + ex * z->r * .4f * s - 2, 4, 4, 0xFF2222);
    }
    for (int i = 0; i < nb; i++) wrect(B[i].x - 2, B[i].y - 2, 4, 4, 0xFFFF00);
    for (int i = 0; i < mode; i++) {
        const Pl *q = &P[i];
        wrect(q->x - 14, q->y - 14, 28, 28, q->dead ? 0x555555 : q->hit > 0 ? 0xFFFFFF : q->col);
        for (int t = 1; t <= 6; t++) wrect(q->x + cosf(q->a) * (8 + t * 4) - 2, q->y + sinf(q->a) * (8 + t * 4) - 2, 4, 4, 0xDDDDDD);
    }
    clip(vx, 0, vw, H);
    rect(vx + 12, 44, 140, 12, 0x330000); rect(vx + 12, 44, 140.f * p->hp / 100, 12, p->hp > 30 ? 0xEE3333 : 0xFF9900);
    text(vx + 12, 62, 3, idx ? "J2" : "J1", 0xFF6A4A, 0);
    if (p->dead) {
        for (int y = 0; y < H; y += 2) rect(vx, y, vw, 1, 0);
        text(vx + vw / 2.f, H / 2.f, 3, "VOCE MORREU - VOLTA NA PROXIMA ONDA", 0xFF5555, 1);
    }
}

static void draw_menu(void) {
    clip(0, 0, W, H);
    if (state == S_PAUSE || state == S_OVER) for (int y = 0; y < H; y += 2) rect(0, y, W, 1, 0);
    float cx = W / 2.f, y = H * .05f; int ts = H / 90 < 3 ? 3 : H / 90, is = H / 180 < 2 ? 2 : H / 180;
    const char *title = "ZOMBIES COMING", *it[5] = {0}; int n = 1; char b[96];
    switch (state) {
    case S_PAUSE: title = "PAUSADO"; it[0] = "CONTINUAR"; it[1] = "MENU PRINCIPAL"; n = 2; break;
    case S_OVER: title = "FIM DE JOGO"; it[0] = "JOGAR DE NOVO"; it[1] = "MENU PRINCIPAL"; n = 2; break;
    case S_HELP: title = "CONTROLES"; it[0] = "VOLTAR"; break;
    case S_TEST: title = "TESTE DE CONTROLE"; it[0] = "VOLTAR"; break;
    default: it[0] = "1 JOGADOR"; it[1] = "2 JOGADORES - TELA DIVIDIDA"; it[2] = "CONTROLES"; it[3] = "TESTAR CONTROLE";
        if (canQuit) { it[4] = "SAIR"; n = 5; } else n = 4;
    }
    if (state == S_MENU) {
        int ls = (H / 5) / 64 < 1 ? 1 : (H / 5) / 64; float lx = cx - 32.f * ls;
        for (int r = 0; r < 64; r++) for (int q = 0; q < 64;) {
            int v = LOGO[r * 64 + q], e = q;
            while (e < 64 && LOGO[r * 64 + e] == v) e++;
            if (v > 2) rect(lx + q * ls, y + r * ls, (float)(e - q) * ls, (float)ls, LOGO_PAL[v]);
            q = e;
        }
        y += 64 * ls + 16;
    }
    text(cx, y, ts, title, 0xFF4A2A, 1); y += 5 * ts + 24;
    if (state == S_OVER) { snprintf(b, sizeof b, "ONDA %d - PONTOS %d - RECORDE %d", wave, score, hi); text(cx, y, 3, b, 0xFFB3A0, 1); y += 50; }
    if (state == S_HELP) {
        static const char *L[] = {"CONTROLE: ANALOGICO ESQUERDO MOVE - DIREITO MIRA", "R2 / R1 / X ATIRA - OPTIONS PAUSA",
            "TECLADO + MOUSE: WASD MOVE - MOUSE MIRA - CLIQUE ATIRA", "2 JOGADORES: J1 TECLADO+MOUSE OU CONTROLE 1",
            "J2 CONTROLE (OU SETAS + ENTER) - QUEM MORRE VOLTA NA ONDA SEGUINTE", "COLETE KITS MEDICOS BRANCOS PARA CURAR"};
        for (int i = 0; i < 6; i++) { text(cx, y, 3, L[i], 0xFFB3A0, 1); y += 36; }
        y += 20;
    }
    if (state == S_TEST) {
        char *s = dbg; float ly = y;
        while (*s) { char *e = strchr(s, '\n'); if (e) *e = 0; text(cx, ly, 3, s, 0xFFB3A0, 1); ly += 32; if (!e) break; *e = '\n'; s = e + 1; }
        y = ly + 20;
    }
    for (int i = 0; i < n; i++) {
        float w = (float)strlen(it[i]) * 4 * is - is;
        if (i == sel) rect(cx - w / 2 - 20, y - 10, w + 40, 5 * is + 20, 0xC01000);
        text(cx, y, is, it[i], i == sel ? 0xFFFFFF : 0xFF9A80, 1); y += 5 * is + 34;
    }
    if (state == S_MENU) { snprintf(b, sizeof b, "RECORDE %d - CONTROLES DETECTADOS: %d", hi, ncon); text(cx, H - 40.f, 2, b, 0x9A3A2A, 1); }
}

void game_draw(void) {
    clip(0, 0, W, H); rect(0, 0, W, H, 0);
    if (state == S_PLAY || state == S_PAUSE || state == S_OVER) {
        int vw = mode == 2 ? W / 2 : W; char b[64];
        for (int i = 0; i < mode; i++) draw_view(&P[i], i * vw, vw, i);
        clip(0, 0, W, H);
        if (mode == 2) rect(W / 2.f - 2, 0, 4, H, 0xC01000);
        snprintf(b, sizeof b, "ONDA %d  PONTOS %d", wave, score); text(W / 2.f, 10, 3, b, 0xFF6A4A, 1);
        if (banner > 0 && state == S_PLAY) { snprintf(b, sizeof b, "ONDA %d", wave); text(W / 2.f, H / 2.f - 90, 8, b, 0xFF6A4A, 1); }
    }
    if (state != S_PLAY) draw_menu();
}
