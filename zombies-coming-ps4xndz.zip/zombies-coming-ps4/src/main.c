/* Zombies Coming - front-end SDL2 (PS4 via OpenOrbis, PC via SDL2). */
#include <math.h>
#include <stdio.h>
#include <string.h>
#if defined(__has_include)
# if __has_include(<SDL2/SDL.h>)
#  include <SDL2/SDL.h>
# else
#  include <SDL.h>
# endif
#else
# include <SDL.h>
#endif
#include "game.h"

/* ---- AJUSTE AQUI se algum botao do controle nao responder ----
   Abra o jogo > "Testar controle": a tela mostra o numero de cada botao/eixo. */
#define PAD_OK     0   /* confirmar no menu (X) */
#define PAD_PAUSE  9   /* pausar (Options) */
#define PAD_FIRE_N 6   /* botoes 0..5 atiram (X, O, quadrado, triangulo, L1, R1) */
#define AX_LX 0
#define AX_LY 1
#define AX_RX 2
#define AX_RY 3
#define AX_L2 4
#define AX_R2 5
/* -------------------------------------------------------------- */

#define MAXJ 2
static SDL_Renderer *R;
static SDL_Joystick *J[MAXJ];
static int nj, restAx[MAXJ][8];

static void fill(int x, int y, int w, int h, uint32_t c) {
    static uint32_t last = 0xFFFFFFFFu;
    if (c != last) { SDL_SetRenderDrawColor(R, (c >> 16) & 255, (c >> 8) & 255, c & 255, 255); last = c; }
    SDL_Rect r = {x, y, w, h};
    SDL_RenderFillRect(R, &r);
}

static void scan_pads(void) {
    static int lastN = -1;
    int n = SDL_NumJoysticks();
    if (n == lastN) return;
    lastN = n;
    for (int i = 0; i < MAXJ; i++) if (J[i]) { SDL_JoystickClose(J[i]); J[i] = NULL; }
    nj = 0;
    for (int i = 0; i < n && nj < MAXJ; i++) {
        SDL_Joystick *j = SDL_JoystickOpen(i);
        if (!j) continue;
        for (int a = 0; a < 8 && a < SDL_JoystickNumAxes(j); a++) restAx[nj][a] = SDL_JoystickGetAxis(j, a);
        J[nj++] = j;
    }
}
static float axf(SDL_Joystick *j, int a) {
    if (!j || a >= SDL_JoystickNumAxes(j)) return 0;
    float v = SDL_JoystickGetAxis(j, a) / 32768.f;
    return fabsf(v) < .25f ? 0 : v;
}
static int trig(int p, int a) {   /* gatilho: conta como apertado se saiu do valor de repouso */
    SDL_Joystick *j = J[p];
    if (!j || a >= 8 || a >= SDL_JoystickNumAxes(j)) return 0;
    return SDL_JoystickGetAxis(j, a) - restAx[p][a] > 16000;
}
static void read_pad(int p, Input *in) {
    SDL_Joystick *j = J[p];
    if (!j) return;
    in->mx += axf(j, AX_LX); in->my += axf(j, AX_LY);
    float rx = axf(j, AX_RX), ry = axf(j, AX_RY);
    if (rx != 0 || ry != 0) { in->ax = rx; in->ay = ry; }
    for (int b = 0; b < PAD_FIRE_N; b++) if (SDL_JoystickGetButton(j, b)) in->f = 1;
    if (trig(p, AX_L2) || trig(p, AX_R2)) in->f = 1;
}
static void build_dbg(char *o, int n) {
    int k = snprintf(o, n, "CONTROLES: %d\n", nj);
    for (int p = 0; p < nj && k < n - 120; p++) {
        SDL_Joystick *j = J[p];
        k += snprintf(o + k, n - k, "C%d EIXOS:", p + 1);
        for (int a = 0; a < 8 && a < SDL_JoystickNumAxes(j); a++) k += snprintf(o + k, n - k, " %d:%d", a, SDL_JoystickGetAxis(j, a) / 1000);
        k += snprintf(o + k, n - k, "\nC%d BOTOES:", p + 1);
        for (int b = 0; b < 24 && b < SDL_JoystickNumButtons(j); b++) if (SDL_JoystickGetButton(j, b)) k += snprintf(o + k, n - k, " %d", b);
        k += snprintf(o + k, n - k, "\n");
    }
    if (nj == 0) snprintf(o + k, n - k, "NENHUM CONTROLE DETECTADO\n");
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    int w = 1280, h = 720, can_quit = 1;
#ifdef ZC_PS4
    w = 1920; h = 1080; can_quit = 0;
#endif
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) != 0 && SDL_Init(SDL_INIT_VIDEO) != 0) return 1;
#ifdef ZC_PS4
    SDL_Window *win = SDL_CreateWindow("Zombies Coming", 0, 0, w, h, 0);
#else
    SDL_Window *win = SDL_CreateWindow("Zombies Coming", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, 0);
#endif
    if (!win) return 1;
    R = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
    if (!R) R = SDL_CreateRenderer(win, -1, 0);
    if (!R) return 1;
    int ow = w, oh = h;
    if (SDL_GetRendererOutputSize(R, &ow, &oh) != 0 || ow < 320 || oh < 240) { ow = w; oh = h; }
    game_init(ow, oh, fill, can_quit);
    scan_pads();

    int run = 1, pu = 0, pd = 0, pok = 0, pps = 0, mx = 0, my = 0;
    float mouseT = 0;
    Uint32 last = SDL_GetTicks(), lastScan = last;
    while (run && !game_quit()) {
        Nav nv; memset(&nv, 0, sizeof nv);
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) run = 0;
            else if (e.type == SDL_KEYDOWN && !e.key.repeat) {
                switch (e.key.keysym.sym) {
                case SDLK_UP: case SDLK_w: nv.up = 1; break;
                case SDLK_DOWN: case SDLK_s: nv.down = 1; break;
                case SDLK_RETURN: case SDLK_KP_ENTER: case SDLK_SPACE: nv.ok = 1; break;
                case SDLK_ESCAPE: case SDLK_p: nv.pause = 1; break;
                default: break;
                }
            } else if (e.type == SDL_MOUSEBUTTONDOWN) { nv.ok = 1; mouseT = 4; }
            else if (e.type == SDL_MOUSEMOTION) mouseT = 4;
        }
        Uint32 now = SDL_GetTicks();
        float dt = (now - last) / 1000.f; last = now; if (dt > .05f) dt = .05f;
        mouseT -= dt;
        if (now - lastScan > 1000) { scan_pads(); lastScan = now; }
        SDL_JoystickUpdate();

        /* menu: navegacao pelo controle (borda de subida) */
        int u = 0, d = 0, ok = 0, ps = 0;
        for (int p = 0; p < nj; p++) {
            float ay = axf(J[p], AX_LY);
            if (ay < -.6f) u = 1;
            if (ay > .6f) d = 1;
            if (SDL_JoystickGetButton(J[p], PAD_OK)) ok = 1;
            if (SDL_JoystickGetButton(J[p], PAD_PAUSE)) ps = 1;
        }
        if (u && !pu) nv.up = 1;
        if (d && !pd) nv.down = 1;
        if (ok && !pok) nv.ok = 1;
        if (ps && !pps) nv.pause = 1;
        pu = u; pd = d; pok = ok; pps = ps;

        /* jogo: teclado + mouse (J1), setas + Enter (J2), controles */
        Input in[2]; memset(in, 0, sizeof in);
        const Uint8 *k = SDL_GetKeyboardState(NULL);
        in[0].mx = (float)(k[SDL_SCANCODE_D] - k[SDL_SCANCODE_A]);
        in[0].my = (float)(k[SDL_SCANCODE_S] - k[SDL_SCANCODE_W]);
        in[1].mx = (float)(k[SDL_SCANCODE_RIGHT] - k[SDL_SCANCODE_LEFT]);
        in[1].my = (float)(k[SDL_SCANCODE_DOWN] - k[SDL_SCANCODE_UP]);
        if (k[SDL_SCANCODE_RETURN] || k[SDL_SCANCODE_RSHIFT]) in[1].f = 1;
        if (SDL_GetMouseState(&mx, &my) & SDL_BUTTON(1)) in[0].f = 1;
        if (mouseT > 0) { in[0].hasM = 1; in[0].mpx = (float)mx; in[0].mpy = (float)my; }
        int pa = -1, pb = -1;                       /* controle de J1 e de J2 */
        if (nj >= 2) { pa = 0; pb = 1; }
        else if (nj == 1) { if (game_players() == 2) pb = 0; else pa = 0; }
        if (pa >= 0) read_pad(pa, &in[0]);
        if (pb >= 0) read_pad(pb, &in[1]);

        char dbg[600]; build_dbg(dbg, sizeof dbg); game_set_debug(dbg);
        game_update(dt, in, nv, nj);
        game_draw();
        SDL_RenderPresent(R);
        if (dt < .004f) SDL_Delay(2);
    }
    SDL_Quit();
    return 0;
}
