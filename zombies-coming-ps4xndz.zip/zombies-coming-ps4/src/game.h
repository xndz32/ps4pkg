/* Zombies Coming - nucleo do jogo (C puro, sem SDL). */
#ifndef GAME_H
#define GAME_H
#include <stdint.h>

typedef struct { float mx, my;      /* mover: -1..1 */
                 float ax, ay;      /* mira por analogico (0 = sem mira) */
                 float mpx, mpy;    /* posicao do mouse em pixels */
                 int f, hasM; } Input;   /* f = atirar, hasM = mouse ativo */
typedef struct { int up, down, ok, pause; } Nav;  /* eventos de menu (1 frame) */
typedef void (*FillFn)(int x, int y, int w, int h, uint32_t rgb);

void game_init(int w, int h, FillFn fill, int can_quit);
void game_update(float dt, const Input in[2], Nav nv, int ncontrols);
void game_draw(void);
void game_set_debug(const char *s);   /* texto da tela "Testar controle" */
int  game_quit(void);
int  game_players(void);
#endif
