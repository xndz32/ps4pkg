# Zombies Coming (PS4, em C)

Sobreviva a ondas de zumbis, sozinho ou em 2 jogadores com tela dividida.
C + SDL2 para o OpenOrbis Toolchain. O ícone (`sce_sys/icon0.png`) é a sua imagem.

## Gerar o .pkg sem PC (só pelo celular, usando o GitHub)
1. No github.com, crie um repositório novo.
2. Na página vazia do repositório, toque em **uploading an existing file**, envie este `.zip` SEM extrair e toque em **Commit changes**.
3. Aba **Actions** > **set up a workflow yourself**. Apague o texto, cole o conteúdo de `ci/build.yml` (também está no fim deste arquivo) e toque em **Commit changes**.
4. O build começa sozinho (3 a 6 minutos). Quando ficar verde, o `.pkg` aparece em **Releases** (página inicial do repositório) e em Actions > resultado.
5. Se ficar vermelho, abra a execução, copie o erro do passo que falhou e mande para mim.

O `.pkg` é de homebrew: só instala em PS4 com homebrew habilitado.

## Gerar o .pkg no computador
Instale `clang` e `lld`, baixe o release do OpenOrbis Toolchain, rode
`export OO_PS4_TOOLCHAIN=/caminho/do/toolchain` e depois `make`.

## Controles
- Controle: analógico esquerdo move, direito mira, R2/R1/X atira, Options pausa.
- PC (mesmo código): WASD move, mouse mira, clique atira. J2: setas + Enter.
- 2 jogadores: J1 teclado+mouse (ou controle 1), J2 controle (ou setas). Quem morre volta na próxima onda.

## Testar no PC
`gcc -O2 src/*.c -o zombies $(sdl2-config --cflags --libs) -lm`

## Limites conhecidos
- Teclado e mouse não funcionam no PS4 (o SDL do OpenOrbis não tem driver para eles).
- Mapeamento dos botões no PS4 é suposição: use **Testar controle** no menu e ajuste os `#define` no topo de `src/main.c`.
- 2 jogadores no PS4 depende do SDL detectar 2 controles.

## ci/build.yml
```yaml
name: Build PS4 PKG
on:
  push:
  workflow_dispatch:
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    env:
      GH_TOKEN: ${{ github.token }}
      GH_REPO: ${{ github.repository }}
    steps:
      - uses: actions/checkout@v4
      - name: Compilar o jogo
        run: |
          unzip -q -o ./*.zip
          cd "$(dirname "$(dirname "$(find . -path '*/ci/build.sh' | head -n 1)")")"
          bash ci/build.sh
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: resultado
          path: "**/*.pkg"
```
