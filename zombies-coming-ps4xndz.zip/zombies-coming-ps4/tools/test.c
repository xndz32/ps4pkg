/* teste headless do nucleo: gcc -fsanitize=address,undefined tools/test.c -lm */
#include "../src/game.c"
#include <stdlib.h>
static uint32_t *fb; static int FW = 1280, FH = 720;
static void fill(int x, int y, int w, int h, uint32_t c) {
    if (x < 0 || y < 0 || x + w > FW || y + h > FH) { fprintf(stderr, "FILL FORA: %d %d %d %d\n", x, y, w, h); exit(2); }
    for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) fb[j * FW + i] = c;
}
static void save(const char *n) {
    FILE *f = fopen(n, "wb"); fprintf(f, "P6\n%d %d\n255\n", FW, FH);
    for (int i = 0; i < FW * FH; i++) { unsigned char p[3] = {fb[i] >> 16, fb[i] >> 8, fb[i]}; fwrite(p, 1, 3, f); }
    fclose(f);
}
static void frame(float dt, Input *in, Nav nv) { game_update(dt, in, nv, 2); game_draw(); }
int main(void) {
    fb = calloc(FW * FH, 4); game_init(FW, FH, fill, 1);
    Input in[2]; Nav nv; memset(in, 0, sizeof in); memset(&nv, 0, sizeof nv);
    frame(.016f, in, nv); save("/tmp/f_menu.ppm");
    nv.down = 1; frame(.016f, in, nv); nv.down = 0; nv.ok = 1; frame(.016f, in, nv); nv.ok = 0;
    if (state != S_PLAY || mode != 2) { puts("FALHA: nao iniciou 2P"); return 1; }
    float t = 0; int maxz = 0;
    for (int i = 0; i < 60 * 70; i++) {
        t += 1 / 60.f;
        in[0].mx = cosf(t * .7f); in[0].my = sinf(t * .7f); in[0].ax = cosf(t * 3); in[0].ay = sinf(t * 3); in[0].f = 1;
        in[1].mx = sinf(t * .5f); in[1].my = -cosf(t * .9f); in[1].ax = sinf(t * 2); in[1].ay = cosf(t * 2); in[1].f = 1;
        in[0].hasM = 0;
        frame(1 / 60.f, in, nv); if (nz > maxz) maxz = nz;
        if (i == 60 * 25) save("/tmp/f_play.ppm");
        if (state == S_OVER) break;
    }
    printf("apos 70s: estado=%d onda=%d pontos=%d zumbis=%d (max %d)\n", state, wave, score, nz, maxz);
    memset(in, 0, sizeof in);
    for (int i = 0; i < 60 * 120 && state == S_PLAY; i++) frame(1 / 60.f, in, nv);
    printf("parado: estado=%d onda=%d pontos=%d recorde=%d\n", state, wave, score, hi);
    frame(.016f, in, nv); save("/tmp/f_over.ppm");
    nv.ok = 1; frame(.016f, in, nv); if (state != S_OVER) { puts("FALHA: lock nao funcionou"); return 1; }
    for (int i = 0; i < 90; i++) frame(1 / 60.f, in, (Nav){0}); frame(.016f, in, nv);
    if (state != S_PLAY) { puts("FALHA: jogar de novo"); return 1; }
    nv = (Nav){0}; nv.pause = 1; frame(.016f, in, nv); nv.pause = 0; frame(.016f, in, nv); save("/tmp/f_pause.ppm");
    nv.down = 1; frame(.016f, in, nv); nv.down = 0; nv.ok = 1; frame(.016f, in, nv); nv.ok = 0;  /* menu principal */
    nv.down = 1; frame(.016f, in, nv); nv.down = 0; nv.down = 1; frame(.016f, in, nv); nv.down = 0; nv.down = 1; frame(.016f, in, nv); nv.down = 0;
    nv.ok = 1; frame(.016f, in, nv); nv.ok = 0;
    game_set_debug("CONTROLES: 2\nC1 EIXOS: 0:0 1:0 2:12 3:-4 4:-32 5:-32\nC1 BOTOES: 0 5"); frame(.016f, in, nv); save("/tmp/f_test.ppm");
    printf("estado final=%d (esperado %d = TEST)\n", state, S_TEST);
    puts("OK"); return 0;
}
